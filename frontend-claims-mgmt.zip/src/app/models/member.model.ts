export interface Member {
    id: number
    mname: string
    address: any
    gender: any
    phone: any
    email: string
    pwd: string
    isadmin: boolean
  }